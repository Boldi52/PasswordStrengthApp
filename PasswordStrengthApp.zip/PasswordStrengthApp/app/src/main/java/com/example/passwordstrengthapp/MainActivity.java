package com.example.passwordstrengthapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigInteger;

public class MainActivity extends AppCompatActivity {

    EditText passwordInput;
    EditText confirmInput;
    TextView strengthText;
    TextView timeText;
    ProgressBar strengthBar;
    Button suggestionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        passwordInput = findViewById(R.id.passwordInput);
        confirmInput = findViewById(R.id.confirmInput);
        strengthText = findViewById(R.id.strengthText);
        timeText = findViewById(R.id.timeText);
        strengthBar = findViewById(R.id.strengthBar);
        suggestionButton = findViewById(R.id.suggestionButton);

        passwordInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkPasswordStrength(s.toString());
                checkPasswordMatch();
                calculateCrackTime(s.toString());
            }
        });

        confirmInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkPasswordMatch();
            }
        });

        suggestionButton.setOnClickListener(v -> showSuggestions());
    }

    private void checkPasswordStrength(String password) {
        int score = 0;

        if (password.length() >= 8) score += 25;
        if (password.matches(".*[A-Z].*")) score += 25;
        if (password.matches(".*[a-z].*")) score += 20;
        if (password.matches(".*[0-9].*")) score += 15;
        if (password.matches(".*[!@#$%^&*+=?-].*")) score += 15;

        strengthBar.setProgress(score);

        if (score < 40) {
            strengthText.setText("Jelszó erőssége: Gyenge");
            strengthBar.setProgressTintList(getColorStateList(android.R.color.holo_red_light));
        } else if (score < 70) {
            strengthText.setText("Jelszó erőssége: Közepes");
            strengthBar.setProgressTintList(getColorStateList(android.R.color.holo_orange_light));
        } else {
            strengthText.setText("Jelszó erőssége: Erős");
            strengthBar.setProgressTintList(getColorStateList(android.R.color.holo_green_light));
        }
    }

    private void calculateCrackTime(String password) {

        if (password.isEmpty()) {
            timeText.setText("Feltörési idő: -");
            return;
        }

        int charsetSize = 0;

        if (password.matches(".*[a-z].*")) charsetSize += 26;
        if (password.matches(".*[A-Z].*")) charsetSize += 26;
        if (password.matches(".*[0-9].*")) charsetSize += 10;
        if (password.matches(".*[!@#$%^&*+=?-].*")) charsetSize += 12;

        if (charsetSize == 0) {
            timeText.setText("Feltörési idő: -");
            return;
        }

        BigInteger combinations = BigInteger.valueOf(charsetSize)
                .pow(password.length());

        // Feltételezett brute force sebesség: 1 milliárd próbálkozás / mp
        BigInteger attemptsPerSecond = BigInteger.valueOf(1_000_000_000);

        BigInteger seconds = combinations.divide(attemptsPerSecond);

        timeText.setText("Feltörési idő: " + formatTime(seconds));
    }

    private String formatTime(BigInteger seconds) {

        BigInteger minute = BigInteger.valueOf(60);
        BigInteger hour = minute.multiply(BigInteger.valueOf(60));
        BigInteger day = hour.multiply(BigInteger.valueOf(24));
        BigInteger year = day.multiply(BigInteger.valueOf(365));

        if (seconds.compareTo(minute) < 0)
            return seconds + " másodperc";

        if (seconds.compareTo(hour) < 0)
            return seconds.divide(minute) + " perc";

        if (seconds.compareTo(day) < 0)
            return seconds.divide(hour) + " óra";

        if (seconds.compareTo(year) < 0)
            return seconds.divide(day) + " nap";

        return seconds.divide(year) + " év";
    }

    private void checkPasswordMatch() {
        String pass = passwordInput.getText().toString();
        String confirm = confirmInput.getText().toString();

        if (!confirm.isEmpty() && !pass.equals(confirm)) {
            confirmInput.setError("A jelszavak nem egyeznek!");
        } else {
            confirmInput.setError(null);
        }
    }

    private void showSuggestions() {
        String password = passwordInput.getText().toString();
        StringBuilder suggestion = new StringBuilder();

        if (password.length() < 8)
            suggestion.append("- Legalább 8 karakter\n");

        if (!password.matches(".*[A-Z].*"))
            suggestion.append("- Legalább egy nagybetű\n");

        if (!password.matches(".*[a-z].*"))
            suggestion.append("- Legalább egy kisbetű\n");

        if (!password.matches(".*[0-9].*"))
            suggestion.append("- Legalább egy szám\n");

        if (!password.matches(".*[!@#$%^&*+=?-].*"))
            suggestion.append("- Legalább egy speciális karakter\n");

        if (suggestion.length() == 0) {
            Toast.makeText(this, "A jelszó már erős! 💪", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, suggestion.toString(), Toast.LENGTH_LONG).show();
        }
    }
}