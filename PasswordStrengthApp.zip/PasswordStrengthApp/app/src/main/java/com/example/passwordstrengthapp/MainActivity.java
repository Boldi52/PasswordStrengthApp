package com.example.passwordstrengthapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText passwordInput;
    EditText confirmInput;
    TextView strengthText;
    ProgressBar strengthBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        passwordInput = findViewById(R.id.passwordInput);
        confirmInput = findViewById(R.id.confirmInput);
        strengthText = findViewById(R.id.strengthText);
        strengthBar = findViewById(R.id.strengthBar);

        passwordInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkPasswordStrength(s.toString());
                checkPasswordMatch();
            }
        });

        confirmInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkPasswordMatch();
            }
        });
    }

    private void checkPasswordStrength(String password) {
        int score = 0;

        if (password.length() >= 8) score += 25;
        if (password.matches(".*[A-Z].*")) score += 25;
        if (password.matches(".*[a-z].*")) score += 20;
        if (password.matches(".*[0-9].*")) score += 15;
        if (password.matches(".*[!@#$%^&*+=?-].*")) score += 15;

        strengthBar.setProgress(score);

        if (score < 40) {
            strengthText.setText("Jelszó erőssége: Gyenge");
            strengthBar.setProgressTintList(getColorStateList(android.R.color.holo_red_light));
        } else if (score < 70) {
            strengthText.setText("Jelszó erőssége: Közepes");
            strengthBar.setProgressTintList(getColorStateList(android.R.color.holo_orange_light));
        } else {
            strengthText.setText("Jelszó erőssége: Erős");
            strengthBar.setProgressTintList(getColorStateList(android.R.color.holo_green_light));
        }
    }

    private void checkPasswordMatch() {
        String pass = passwordInput.getText().toString();
        String confirm = confirmInput.getText().toString();

        if (!confirm.isEmpty() && !pass.equals(confirm)) {
            confirmInput.setError("A jelszavak nem egyeznek!");
        }
    }
}
